local l = (data.bl and 1) or -1
local player = data.player
local item = data.item
local mainHand = data.mainHand

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

-- fishing пиздец

if I:isOf(item, Items:get("minecraft:fishing_rod")) then
    animator:rotateZ( 0, 19, M:clamp(P:getPitch(player) / 1, -25, 90) + ptAngle, 0.3, 1.9, 0.5, 0.4)
    animator:rotateX( 0, 19, M:clamp(P:getPitch(player) / 1, 0, 0) + ywAngle, 0.3, 1.9, 0.5, 0.4)
    animator:moveX(0, 19, -0.1)
end	

if I:isOf(item, Items:get("minecraft:warped_fungus_on_a_stick")) or I:isOf(item, Items:get("minecraft:carrot_on_a_stick")) then
    animator:rotateZ( 0, 40, M:clamp(P:getPitch(player) / 1, -25, 90) + ptAngle, 0.3, 1.9, 0.5, 0.4)
    animator:rotateX( 0, 40, M:clamp(P:getPitch(player) / 1, 0, 0) + ywAngle, 0.3, 1.9, 0.5, 0.4)
    animator:moveX(0, 40, -0.1)
end

-- Banner Pattern

if I:isOf(item, Items:get("minecraft:flower_banner_pattern")) or I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) or I:isOf(item, Items:get("minecraft:skull_banner_pattern")) or I:isOf(item, Items:get("minecraft:mojang_banner_pattern"))or I:isOf(item, Items:get("minecraft:globe_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern"))or I:isOf(item, Items:get("minecraft:flow_banner_pattern")) or I:isOf(item, Items:get("minecraft:guster_banner_pattern")) or I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) or I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) then
    animator:rotateX( 6, 7, M:clamp(P:getPitch(player) / 1, -40, 90) + ptAngle, 0.4, 0.5, 0.5, -0.5)
    animator:rotateZ( 6, 7, M:clamp(P:getPitch(player) / 1, 0, 0) - ywAngle, 0.4, 0.5, 0.5, -0.5)
    animator:moveY(6, 7, 0.03)
end

if I:isOf(item, Items:get("minecraft:wheat_seeds")) or I:isOf(item, Items:get("minecraft:pumpkin_seeds")) or I:isOf(item, Items:get("minecraft:melon_seeds")) or I:isOf(item, Items:get("minecraft:beetroot_seeds")) or I:isOf(item, Items:get("minecraft:torchflower_seeds")) or I:isOf(item, Items:get("minecraft:cocoa_beans")) then
    animator:rotateX( 0, 100, M:clamp(P:getPitch(player) / -1, -90, 20) - ptAngle + ywAngle * 1, 0, 0.6, 0.6)
	animator:rotateZ( 0, 7, M:clamp(P:getPitch(player) / 10, -5, 10) + ptAngle, 0.8, 0.5, 0.0, 0.0)
end

if I:isOf(item, Items:get("minecraft:brush")) then
    animator:rotateZ( 0, 20, ywAngle, 0.5, 0.65, 0.0)
    animator:moveY(0, 20, -0.02)
end

if I:isOf(item, Items:get("minecraft:stick")) then
	animator:rotateZ( 0, 2, M:clamp(P:getPitch(player) / 10, -5, 0) - ptAngle, 0.4, 0.8, 0.0, 0.0)
end

if I:isOf(item, Items:get("minecraft:string")) then
    animator:rotateX( 0, 2, M:clamp(P:getPitch(player) / -1, 0, 70) + ptAngle + ywAngle * 1, 0, 0.141, 0.299)
end

if I:isOf(item, Items:get("minecraft:totem_of_undying")) then
-- arms
	animator:rotateZ( 0, 5, M:clamp(P:getPitch(player) / -1, -5, 0) + ptAngle, 0.58, 0.35, 2, 0.4)
	animator:rotateZ( 6, 11, M:clamp(P:getPitch(player) / -1, -5, 0) - ptAngle, 0.3, 0.35, 2, 0.4)
-- hair	
	animator:rotateZ( 36, 49, M:clamp(P:getPitch(player) / -1, -5, 0) + ptAngle, 0.7, 0.7, 2, 0.4)
	animator:rotateZ( 49, 63, M:clamp(P:getPitch(player) / -1, -5, 0) - ptAngle, 0.25, 0.7, 2, 0.4)
-- head
	animator:rotateZ( 12, 63, - ywAngle, 0.5, 0.4, 2, 0.4)
end


-- Other Stuff

if I:isOf(item, Items:get("minecraft:bamboo_chest_raft")) then
    animator:moveY(0, 62, 0.1)
end

if I:isOf(data.item, Items:get("minecraft:paper")) or I:isOf(data.item, Items:get("minecraft:map")) then
    animator:rotateX( 4, 7, M:clamp(P:getPitch(player) / 1, -25, 30) + ptAngle + ywAngle * 1, 0, 0.4, 0.505)
    animator:rotateX( 2, 5, M:clamp(P:getPitch(player) / 1, -20, 20) + ptAngle + ywAngle * 1, 0, 0.03, 0.28)
end

if I:isOf(data.item, Items:get("minecraft:name_tag")) then
    animator:rotateX( 0, 5, M:clamp(P:getPitch(player) / 1, -90, 90) + ptAngle * 1, 0, 0.2, 0.4)
    animator:rotateZ( 0, 5, -ywAngle, 0.5, 0.2, 0.4)
end

if I:isOf(data.item, Items:get("minecraft:writable_book")) then
    animator:rotateZ( 0, 1, M:clamp(P:getPitch(player) / 1, -45, -10) + ptAngle + ywAngle * 1, 0.5, 0.1, 1)
end

if I:isOf(data.item, Items:get("minecraft:armor_stand")) then
    animator:rotateZ( 0, 41, -ywAngle, 0.5, 0, 0)
end


if I:isOf(data.item, Items:get("minecraft:white_harness")) or
   I:isOf(data.item, Items:get("minecraft:light_gray_harness")) or
   I:isOf(data.item, Items:get("minecraft:gray_harness")) or
   I:isOf(data.item, Items:get("minecraft:black_harness")) or
   I:isOf(data.item, Items:get("minecraft:brown_harness")) or
   I:isOf(data.item, Items:get("minecraft:red_harness")) or
   I:isOf(data.item, Items:get("minecraft:orange_harness")) or
   I:isOf(data.item, Items:get("minecraft:yellow_harness")) or
   I:isOf(data.item, Items:get("minecraft:lime_harness")) or
   I:isOf(data.item, Items:get("minecraft:green_harness")) or
   I:isOf(data.item, Items:get("minecraft:cyan_harness")) or
   I:isOf(data.item, Items:get("minecraft:light_blue_harness")) or
   I:isOf(data.item, Items:get("minecraft:blue_harness")) or
   I:isOf(data.item, Items:get("minecraft:purple_harness")) or
   I:isOf(data.item, Items:get("minecraft:magenta_harness")) or
   I:isOf(data.item, Items:get("minecraft:pink_harness")) then
	animator:rotateZ( 0, 25, M:clamp(P:getPitch(player) / 1, 0, 40) + ptAngle, 0.8, 0.4, 2, 0.4)
	animator:rotateZ( 26, 51, M:clamp(P:getPitch(player) / -1, -40, 0) - ptAngle, 0.1, 0.4, 2, 0.4)
	animator:rotateX( 52, 66, M:clamp(P:getPitch(player) / 1, 0, 0) + ptAngle, 0.5, 0.4, 0.4, 0.4)
end

if I:isOf(data.item, Items:get("minecraft:seagrass")) then
    animator:rotateX( 2, 3, M:clamp(P:getPitch(player) / 1, -25, 30) + ptAngle + ywAngle * 1, 0, 0.31, 0.5)
end

if I:isOf(data.item, Items:get("minecraft:kelp")) then
    animator:rotateX( 2, 3, M:clamp(P:getPitch(player) / 1, -25, 30) + ptAngle + ywAngle * 1, 0, 0.31, 0.5)
end

if I:isOf(data.item, Items:get("minecraft:white_banner")) or I:isOf(data.item, Items:get("minecraft:orange_banner")) or I:isOf(data.item, Items:get("minecraft:magenta_banner")) or I:isOf(data.item, Items:get("minecraft:light_blue_banner")) or I:isOf(data.item, Items:get("minecraft:yellow_banner")) or I:isOf(data.item, Items:get("minecraft:lime_banner")) or I:isOf(data.item, Items:get("minecraft:pink_banner")) or I:isOf(data.item, Items:get("minecraft:gray_banner")) or I:isOf(data.item, Items:get("minecraft:light_gray_banner")) or I:isOf(data.item, Items:get("minecraft:cyan_banner")) or I:isOf(data.item, Items:get("minecraft:purple_banner")) or I:isOf(data.item, Items:get("minecraft:blue_banner")) or I:isOf(data.item, Items:get("minecraft:brown_banner")) or I:isOf(data.item, Items:get("minecraft:green_banner")) or I:isOf(data.item, Items:get("minecraft:red_banner")) or I:isOf(data.item, Items:get("minecraft:black_banner"))
then
    animator:rotateX(0, 6, M:clamp(P:getPitch(player) / -1, -75, 5) - ptAngle - ywAngle * 1, 0, 1.08, 0.6)
end



